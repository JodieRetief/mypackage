from mypackage import myModule

def test_top_n():
    assert myModule.top_n([8,7,2,3,4], 3) == [8,7,4], 'incorrect'
    # repeat for more lists

    